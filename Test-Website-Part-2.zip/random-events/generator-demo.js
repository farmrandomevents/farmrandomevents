// Site-styled, keyboard/controller-friendly confirmation and warning dialogs.
function farmDialog(message,{title='Please Confirm',confirm=false,confirmLabel='Confirm',onConfirm=()=>{}}={}){
 const previous=document.activeElement;
 const overlay=document.createElement('div');overlay.className='farm-dialog-overlay';
 overlay.setAttribute('role','presentation');
 const panel=document.createElement('div');panel.className='farm-dialog';panel.setAttribute('role','alertdialog');panel.setAttribute('aria-modal','true');
 const heading=document.createElement('h2');heading.textContent=title;heading.id='farm-dialog-title';panel.setAttribute('aria-labelledby',heading.id);
 const description=document.createElement('p');description.textContent=message;description.id='farm-dialog-description';panel.setAttribute('aria-describedby',description.id);
 const actions=document.createElement('div');actions.className='farm-dialog-actions';
 const close=()=>{overlay.remove();previous?.focus?.()};
 const cancel=document.createElement('button');cancel.type='button';cancel.textContent=confirm?'Cancel':'OK';cancel.className='farm-dialog-cancel';cancel.onclick=close;
 actions.append(cancel);
 if(confirm){const yes=document.createElement('button');yes.type='button';yes.textContent=confirmLabel;yes.className='farm-dialog-confirm';yes.onclick=()=>{close();onConfirm()};actions.append(yes)}
 panel.append(heading,description,actions);overlay.append(panel);document.body.append(overlay);
 overlay.addEventListener('keydown',e=>{if(e.key==='Escape'||e.key==='Backspace'){e.preventDefault();close()}else if(e.key==='Tab'){const buttons=[...actions.querySelectorAll('button')];const i=buttons.indexOf(document.activeElement);if(e.shiftKey&&i===0){e.preventDefault();buttons.at(-1).focus()}else if(!e.shiftKey&&i===buttons.length-1){e.preventDefault();buttons[0].focus()}}});
 cancel.focus();
}
const $=id=>document.getElementById(id);
const categorySlugs=["weather", "crops-fields", "machinery", "animals", "supplies-storage", "finance", "contracts-neighbours", "dealership", "challenges", "community"];
const cats=['Weather','Crops & Fields','Machinery','Animals','Supplies & Storage','Finance','Contracts & Neighbours','Dealership','Challenges','Community'];
// Test content only; revised website events will replace these entries.
const DEMO_IDS=["weather-2026-04", "weather-2026-07", "weather-2026-10", "weather-2026-18", "book-02-048", "book-02-052", "book-02-054", "book-02-060"];
const events=Object.keys(window.FSG_EVENT_CATEGORIES).sort((a,b)=>Number(a)-Number(b)).flatMap(k=>window.FSG_EVENT_CATEGORIES[k]).filter(e=>DEMO_IDS.includes(e.id));
const animalNames=['Cattle','Sheep','Pigs','Chickens','Goats','Horses','Water Buffalo','Bees','Alpacas'];
const cropNames=['Wheat', 'Barley', 'Oats', 'Canola', 'Soybeans', 'Corn', 'Sorghum', 'Sunflowers', 'Potatoes', 'Sugar Beet', 'Cotton', 'Rice', 'Long Grain Rice', 'Grapes', 'Olives', 'Sugarcane', 'Poplar', 'Grass', 'Onions', 'Coffee', 'Bananas'];
const cropEventMap={"book-01-030":"Wheat","book-01-031":"Wheat","book-01-032":"Barley","book-01-033":"Oats","book-01-034":"Corn","book-01-035":"Canola","book-01-036":"Potatoes"};
const months=['January','February','March','April','May','June','July','August','September','October','November','December'];
const KEY='fsg-demo-events-v1';
let state={selected:cats.map((_,i)=>i),current:null,used:[],active:[],categoriesOpen:true,tracking:false,calendar:null,frequency:'manual',count:'1',periodKey:null,periodEvents:[],scheduleAnchor:null,monthSeen:{},lastGenerated:null,sequence:0,animalsOwned:[],cropsOwned:[],areaUnit:'acres',currency:'GBP',minEvents:null,maxEvents:null};
try{const s=JSON.parse(localStorage.getItem(KEY));if(s&&typeof s==='object')state={...state,...s}}catch(e){}
if(!Array.isArray(state.selected))state.selected=cats.map((_,i)=>i);
if(!Array.isArray(state.active))state.active=[];
if(!Array.isArray(state.periodEvents))state.periodEvents=[];
if(!Array.isArray(state.used))state.used=[];
if(!Array.isArray(state.cropsOwned))state.cropsOwned=[];
if(!Array.isArray(state.animalsOwned))state.animalsOwned=[];
if(!['acres','hectares'].includes(state.areaUnit))state.areaUnit='acres';
if(!['GBP','EUR','USD'].includes(state.currency))state.currency='GBP';
// Existing farms retain their previous fixed event count as their initial range.
if(state.minEvents===null||!Number.isFinite(Number(state.minEvents)))state.minEvents=state.count==='random'?1:Number(state.count)||1;
if(state.maxEvents===null||!Number.isFinite(Number(state.maxEvents)))state.maxEvents=state.count==='random'?10:Number(state.count)||1;
state.minEvents=Math.max(0,Math.min(10,Number(state.minEvents)));
state.maxEvents=Math.max(state.minEvents,Math.min(10,Number(state.maxEvents)));
// Demo-only state: keep the same calendar and event rendering as the full generator.
state.selected=[0,2];state.frequency='1';state.minEvents=1;state.maxEvents=1;state.count='1';state.tracking=true;
if(!state.calendar)state.calendar={month:2,day:1,daysPerMonth:3,year:0};
if(state.scheduleAnchor===null)state.scheduleAnchor=(state.calendar.year||0)*12+state.calendar.month;
// Persist a shuffled eight-event cycle separately from the full-version save.
function demoChoose(pool){
 const available=pool.filter(e=>!state.used.includes(e.id));
 if(!available.length){state.used=[];return pool[Math.floor(Math.random()*pool.length)]||null;}
 return available[Math.floor(Math.random()*available.length)]||null;
}
const currencySymbols={GBP:'£',EUR:'€',USD:'$'};
function currencySymbol(){return currencySymbols[state.currency]||'£'}
function currencyText(value){return String(value??'').replace(/£/g,currencySymbol())}
function money(n){return currencySymbol()+Math.round(n).toLocaleString('en-GB')}
state.animalsOwned=[...new Set(state.animalsOwned.map(a=>a==='Cows'?'Cattle':a))];
if(!state.monthGenerated||typeof state.monthGenerated!=='object')state.monthGenerated={};
if(state.calendar){state.calendar.daysPerMonth=Math.max(1,Math.min(28,Number(state.calendar.daysPerMonth)||1));state.calendar.day=Math.max(1,Math.min(state.calendar.daysPerMonth,Number(state.calendar.day)||1));}
if(!state.monthSeen||typeof state.monthSeen!=='object')state.monthSeen={};
function updateCalculator(){const price=Math.max(0,Number($('calcPrice').value)||0);const pct=Math.min(100,Math.max(0,Number($('calcPercent').value)||0));const saving=price*pct/100;const isDiscount=$('calcKind').value==='discount';$('calcResult').innerHTML=isDiscount?`<strong>Receive ${money(saving)} from your Payment Farm</strong><div>Final purchase cost: ${money(price-saving)}</div>`:`<strong>Receive ${money(saving)} from your Payment Farm</strong><div>Total sale value: ${money(price+saving)}</div>`;}
const calcPriceOptions=$('calcPriceOptions');
[1000,5000,10000,25000,50000,100000,250000,500000].forEach(price=>{const b=document.createElement('button');b.type='button';b.dataset.price=String(price);b.textContent=money(price);b.addEventListener('click',()=>{$('calcPrice').value=String(Math.max(0,Number($('calcPrice').value)||0)+price);updateCalculator()});calcPriceOptions.append(b)});

$('calcClear').addEventListener('click',()=>{$('calcPrice').value='0';updateCalculator()});
const calcPercentOptions=$('calcPercentOptions');
for(let pct=0;pct<=100;pct+=5){const btn=document.createElement('button');btn.type='button';btn.textContent=pct+'%';btn.setAttribute('aria-pressed',String(pct===Number($('calcPercent').value)));btn.addEventListener('click',()=>{$('calcPercent').value=String(pct);syncCalcPercentButtons();updateCalculator();});calcPercentOptions.append(btn)}
function syncCalcPercentButtons(){Array.from(calcPercentOptions.children).forEach(btn=>btn.setAttribute('aria-pressed',String(parseInt(btn.textContent,10)===Number($('calcPercent').value))))}
['calcPrice','calcPercent','calcKind'].forEach(id=>$(id).addEventListener('input',updateCalculator));$('calcToggle').addEventListener('click',()=>{const body=$('calcBody');body.hidden=!body.hidden;$('calcToggle').setAttribute('aria-expanded',String(!body.hidden));$('calcToggle').textContent=(body.hidden?'▸':'▾')+' Percentage & Payment Farm Calculator (optional tool)';});updateCalculator();
function persist(){try{localStorage.setItem(KEY,JSON.stringify(state))}catch(e){}}
function randomFrom(a){return a[Math.floor(Math.random()*a.length)]}
function dateLabel(c){return c?`${months[c.month]}, Year ${(c.year||0)+1}, Day ${c.day}`:'No farm calendar'}
function monthKey(){const c=state.calendar;return c?`${c.year||0}-${c.month}${state.frequency==='daily'?'-'+c.day:''}`:null}
// Shared duration rules for ALL event categories, not only weather.
// Long-term month-based events and instant events retain their own behaviour.
function durationFor(e){
 if(!e.duration)return null;
 const dpm=Math.max(1,Math.min(28,Number(state.calendar?.daysPerMonth)||3));
 if(e.duration==='months'){
  const lo=Math.max(1,e.minMonths||1),hi=Math.max(lo,e.maxMonths||lo);
  const n=lo+Math.floor(Math.random()*(hi-lo+1));
  return {amount:n,unit:'months',label:`${n} ${n===1?'month':'months'}`,total:n*dpm};
 }
 // All day-based timed events draw a duration suited to the player's calendar.
 // One-day months use a half-day restriction, which expires at the next advance.
 if(dpm===1)return {amount:.5,unit:'days',label:'until 12pm (half a day)',total:1};
 const max=dpm===2?1:dpm===3?2:dpm<=7?4:8;
 const n=1+Math.floor(Math.random()*max);
 return {amount:n,unit:'days',label:`${n} ${n===1?'day':'days'}`,total:n};
}
function isPendingOffer(e){
 if(e.c!==7)return false;
 const t=(e.t+' '+e.template).toLowerCase();
 return /next (tractor|machine|vehicle|implement|purchase|repair|upgrade|used|new)|towards (your|one|a|any)|discount on (one|your|the next)|voucher|trade-in bonus|customer reward|loyalty reward|free (repair|repaint|tune-up|fuel)|tyre upgrade|engine upgrade|parts voucher|dealer discount|seasonal promotion|attachment offer|used machinery deal/.test(t);
}
function instantiate(e){const dur=isPendingOffer(e)?null:durationFor(e);const amount=e.amounts?randomFrom(e.amounts):null;const animal=e.id==='weather-2026-20'?randomFrom(state.animalsOwned):null;const description=e.template.replace('{animal}',animal?animal.toLowerCase():'livestock');return {id:`event-${Date.now()}-${++state.sequence}`,eventId:e.id,title:e.t,category:e.c,photo:e.p,description:description.replace('{duration}',dur?.label||'').replace('{amount}',amount===null?'':amount.toLocaleString('en-GB')),duration:dur,eventType:e.eventType||null,pendingOffer:isPendingOffer(e),completed:false,remaining:dur?.total||0,total:dur?.total||0,created:state.calendar?{...state.calendar}:null,finished:null};}
function markSeen(e){if(!state.tracking||!state.calendar)return;const key=`${state.calendar.year||0}-${state.calendar.month}`;if(!key)return;const a=state.monthSeen[key]||[];if(!a.includes(e.id))a.push(e.id);state.monthSeen[key]=a;}
function eligible(){return events.filter(e=>state.selected.includes(e.c)&&(e.c!==1||state.cropsOwned.length>0)&&(e.c!==3||state.animalsOwned.length>0)&&(!e.requiresAnimals||state.animalsOwned.length>=e.requiresAnimals)&&(!e.animals||e.animals.some(a=>state.animalsOwned.includes(a==='Cows'?'Cattle':a)))&&(!cropEventMap[e.id]||state.cropsOwned.includes(cropEventMap[e.id]))&&(!state.tracking||!state.active.some(a=>!a.completed&&a.eventId===e.id)))}
function chooseUnique(pool,used){const a=pool.filter(e=>!used.includes(e.id));return a.length?randomFrom(a):null}
function drawCats(){
 $('all').textContent='Weather & Machinery Only';$('all').disabled=true;$('all').title='Other categories are included in the full version';
 $('categories').hidden=!state.categoriesOpen;
 $('categoryHeading').hidden=!state.categoriesOpen;
 $('all').hidden=!state.categoriesOpen;
 $('hideCats').setAttribute('aria-expanded',String(state.categoriesOpen));
 $('hideCats').textContent=state.categoriesOpen?'Hide Categories ▴':'Show Categories ▾';
 $('categories').replaceChildren();
 cats.forEach((c,i)=>{
   const wrap=document.createElement('div');wrap.className='category-wrap';
   const b=document.createElement('button');b.className='category';b.type='button';
   b.setAttribute('aria-pressed',String(state.selected.includes(i)));
   b.innerHTML=`<span class="tick">✓</span><img src="images/${categorySlugs[i]}/cat-${i}.webp" alt=""><span class="name">${c}</span>`;
   const locked=![0,2].includes(i);
   b.disabled=locked;
   b.title=locked?'Full version — unlock this event category':'Included in the free demo';
   if(locked){b.classList.add('demo-locked');b.setAttribute('aria-label',c+' — locked in free demo');b.insertAdjacentHTML('beforeend','<span class="demo-lock-overlay" aria-hidden="true"><span class="demo-lock-symbol"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><rect x="5" y="10" width="14" height="11" rx="2" fill="#d8ad51" stroke="#f5d489" stroke-width="1"/><path d="M8 10V7a4 4 0 0 1 8 0v3" fill="none" stroke="#f5d489" stroke-width="2.7" stroke-linecap="round"/><circle cx="12" cy="15" r="1.4" fill="#173b29"/><path d="M12 16v2" stroke="#173b29" stroke-width="1.5" stroke-linecap="round"/></svg></span><span class="demo-lock-label">FULL VERSION</span></span>');}
   b.onclick=()=>{if(locked)return; /* Demo categories remain enabled so all eight events can be sampled. */};
   wrap.append(b);
   $('categories').append(wrap);
 });
}
function showEvent(v){if(!v)return;state.current=v;$('cat').textContent=cats[v.category].toUpperCase()+' • RANDOM EVENT';$('title').textContent=v.title;$('desc').textContent=displayEventDescription(v);// Load an individual event banner by title, falling back to the category banner.
 const photo=$('photo');
 const folder='images/'+categorySlugs[v.category]+'/';
 const fallback=folder+'event-'+v.category+'.webp';
 const slug=String(v.title||'').toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
 photo.onerror=()=>{photo.onerror=null;photo.src=fallback;};
 photo.src=folder+slug+'.webp';$('photo').alt=v.title+' farming scene';renderThumbnails();renderBannerCompletion();}
function findTracked(v){return state.active.find(x=>x.id===v?.id)}
function completeAction(id){
 const item=state.active.find(x=>x.id===id);
 if(!item||(!item.actionRequired&&!item.earlyChoice)||item.completed)return;
 item.completed=true;item.actionRequired=false;item.finished=state.calendar?{...state.calendar}:null;
 persist();renderTracker();renderBannerCompletion();syncCleanLayout();
}
function renderBannerCompletion(){
 const b=$('bannerComplete'), item=findTracked(state.current);
 // A completed badge remains gold for the in-game day it was finished.
 // After the player advances their farm calendar, it disappears from the banner;
 // the completion itself remains saved in Farm Event History.
 const finishedToday=!!(item?.completed && item.finished && state.calendar &&
   item.finished.year===state.calendar.year &&
   item.finished.month===state.calendar.month &&
   item.finished.day===state.calendar.day);
 // Without a farm calendar, retain the badge for the current generated batch.
 const finishedWithoutCalendar=!!(item?.completed && !state.calendar);
 const showCompleted=finishedToday || finishedWithoutCalendar;
 b.hidden=!(item && (showCompleted || (!item.completed && (item.actionRequired || item.earlyChoice))));
 if(b.hidden)return;
 const done=showCompleted;
 b.disabled=done;
 b.textContent=done?'✓ Completed':item.pendingOffer?'✓ Apply Offer When Used':item.earlyChoice?'✓ I chose the early solution':'✓ Mark as Completed';
 b.style.backgroundColor=done?'#D8AD51':'';
 b.style.color=done?'#173B29':'';
 b.style.borderColor=done?'#D8AD51':'';
 b.style.opacity='1';
 b.onclick=done?null:()=>completeAction(item.id);
}
function displayDuration(days){
 const dpm=state.calendar?.daysPerMonth||3;
 if(days===.5)return 'Half a day';
  const n=Math.ceil(days);return `${n} day${n===1?'':'s'}`;
}
function formatAreaText(str){
 return String(str||'').replace(/\{area10\}/g,state.areaUnit==='hectares'?'4.05 hectares':'10 acres');
}
function displayEventDescription(item){
 if(!item)return '';
 const duration=item.duration;
 if(!duration)return currencyText(formatAreaText(item.description));
 const label=duration.label|| (duration.unit==='months'?`${duration.amount} month${duration.amount===1?'':'s'}`:displayDuration(duration.amount));
 return currencyText(formatAreaText(item.description.replace(duration.label,label)));
}
function renderThumbnails(){const list=state.periodEvents.length?state.periodEvents:(state.current?[state.current]:[]);const controls=$('carouselControls');controls.hidden=list.length<2;const index=Math.max(0,list.findIndex(e=>e.id===state.current?.id));$('eventPosition').textContent=`Event ${index+1} of ${list.length}`;}
function shiftEvent(direction){const list=state.periodEvents;if(list.length<2)return;const index=Math.max(0,list.findIndex(e=>e.id===state.current?.id));showEvent(list[(index+direction+list.length)%list.length]);persist();}
$('eventPrev').onclick=()=>shiftEvent(-1);$('eventNext').onclick=()=>shiftEvent(1);

// Phone swipe navigation: only the event photograph is swipeable.
// Uses the existing Previous/Next logic, preserving completion and farm progress.
{
 const photo=$('photo');
 let startX=0,startY=0,trackingSwipe=false;
 photo.addEventListener('touchstart',e=>{
  if(e.touches.length!==1){trackingSwipe=false;return;}
  startX=e.touches[0].clientX;startY=e.touches[0].clientY;trackingSwipe=true;
 },{passive:true});
 photo.addEventListener('touchend',e=>{
  if(!trackingSwipe||!e.changedTouches.length)return;
  trackingSwipe=false;
  const dx=e.changedTouches[0].clientX-startX;
  const dy=e.changedTouches[0].clientY-startY;
  // Ignore taps and vertical page scrolling.
  if(Math.abs(dx)<55||Math.abs(dx)<Math.abs(dy)*1.4)return;
  shiftEvent(dx<0?1:-1);
 },{passive:true});
 photo.addEventListener('touchcancel',()=>{trackingSwipe=false;},{passive:true});
}

function autoTrack(v){if(!state.tracking||!state.calendar)return;const copy={...v,created:v.created||{...state.calendar}};
// Immediate events have no ongoing duration and go straight into history.
if(!copy.total){copy.actionRequired=true;copy.completed=false;}
if(copy.pendingOffer){copy.actionRequired=true;copy.completed=false;}
if(copy.eventType==='choice')copy.earlyChoice=true;
state.active.push(copy);}
function generate(){state.selected=[0,2];state.minEvents=1;state.maxEvents=1;state.frequency='1';
 const scheduled=state.tracking&&state.calendar&&state.frequency!=='manual';
 if(scheduled&&!dueForPeriod()){$('status').textContent='No events due this month. Advance your farm calendar.';return;}
 const period=scheduled?`${state.frequency}:${periodId()}`:null;
 if(state.tracking&&state.calendar&&state.monthGenerated[monthKey()]){
   $('status').textContent='All events for this scheduled period have already been generated. Use the arrows to view them.';return;
 }
 const count=state.minEvents+Math.floor(Math.random()*(state.maxEvents-state.minEvents+1));
  if(count===0){state.periodEvents=[];if(scheduled)state.periodKey=period;if(state.tracking&&state.calendar)state.monthGenerated[monthKey()]=true;persist();renderTracker();renderSchedule();syncCleanLayout();$('status').textContent='A quiet period on the farm — no random events this time.';return;}
 const pool=eligible();const seen=state.tracking&&state.calendar?(state.monthSeen[`${state.calendar.year||0}-${state.calendar.month}`]||[]):[];
 // Monthly uniqueness applies within the current month, including events already generated.
 // An existing batch is never extended by another click in the same scheduled period.
 const chosen=[];
 for(let i=0;i<count;i++){
   const next=demoChoose(pool.filter(e=>!e.conflictGroup||!chosen.some(c=>c.conflictGroup===e.conflictGroup)));
   if(!next)break;
   chosen.push(next);
 }
 if(!chosen.length){$('status').textContent='No unused eligible events remain this month. Advance the calendar or select more categories.';return;}
 state.periodEvents=chosen.map(e=>{markSeen(e);if(!state.used.includes(e.id))state.used.push(e.id);const v=instantiate(e);autoTrack(v);return v});
 if(scheduled)state.periodKey=period;
 if(state.tracking&&state.calendar)state.monthGenerated[monthKey()]=true;
 showEvent(state.periodEvents[0]);if(state.periodEvents.some(e=>!e.total)&&state.tracking){ongoingOpen=true;state.ongoingOpen=true;}persist();renderTracker();renderSchedule();syncCleanLayout();
 $('status').textContent=state.periodEvents.length<count?`${state.periodEvents.length} of ${count} events generated: only ${state.periodEvents.length} different eligible events remain this month. Select more categories or advance the calendar.`:`${state.periodEvents.length} different event${state.periodEvents.length===1?'':'s'} generated together. Use Previous and Next to see each one. Farm date unchanged.`;
}
$('generate').onclick=mainGoldAction;$('sticky').onclick=()=>{mainGoldAction();$('event').scrollIntoView({behavior:'smooth',block:'center'})};
$('hideCats').onclick=()=>{state.categoriesOpen=!state.categoriesOpen;persist();drawCats()};
$('all').hidden=true;$('all').onclick=()=>{};
function fillSelect(id,opts){const el=$(id);el.replaceChildren();opts.forEach(([v,t])=>{const o=document.createElement('option');o.value=v;o.textContent=t;el.append(o)})}
fillSelect('startMonth',months.map((m,i)=>[i,m]));
function refreshDays(){const n=Number($('daysPerMonth').value)||3;$('daysPerMonthValue').textContent=String(n);const old=Number($('startDay').value)||1;fillSelect('startDay',Array.from({length:n},(_,i)=>[i+1,'Day '+(i+1)]));$('startDay').value=String(Math.min(n,old))}
$('daysPerMonth').oninput=refreshDays;
$('daysMinus').onclick=()=>{$('daysPerMonth').value=String(Math.max(1,Number($('daysPerMonth').value)-1));refreshDays()};
$('daysPlus').onclick=()=>{$('daysPerMonth').value=String(Math.min(28,Number($('daysPerMonth').value)+1));refreshDays()};
function openSettings(){const c=state.calendar||{month:2,day:1,daysPerMonth:3};$('startMonth').value=String(c.month);$('daysPerMonth').value=String(c.daysPerMonth);refreshDays();$('startDay').value=String(c.day);$('calendarSettings').hidden=false}
$('calendarEdit').onclick=openSettings;$('calendarCancel').onclick=()=>{if(state.calendar)$('calendarSettings').hidden=true};
$('calendarSave').onclick=()=>{const prev=state.calendar;const next={month:Number($('startMonth').value),day:Number($('startDay').value),daysPerMonth:Number($('daysPerMonth').value),year:prev?.year||0};/* Changing settings must not silently advance the year. */next.day=Math.max(1,Math.min(next.day,next.daysPerMonth));state.calendar=next;if(prev&&(prev.month!==next.month||prev.year!==next.year))state.scheduleAnchor=next.year*12+next.month;if(state.scheduleAnchor===null)state.scheduleAnchor=next.year*12+next.month;$('calendarSettings').hidden=true;if(!prev||prev.month!==next.month||prev.year!==next.year){state.periodEvents=[];state.current=null;}persist();renderTracker();renderSchedule();syncCleanLayout()};
function renderTracker(){const running=state.active.filter(x=>!x.completed&&!x.actionRequired).sort((a,b)=>String(b.id).localeCompare(String(a.id)));$('activeCount').textContent=running.length;$('activeSummary').textContent=running.length+' active';const c=state.calendar;$('calendarDate').textContent=c?`${months[c.month]}, Year ${(c.year||0)+1} — Day ${c.day} of ${c.daysPerMonth}`:'Set up your calendar';$('calendarInfo').textContent=c?`${c.daysPerMonth} day${c.daysPerMonth===1?'':'s'} per month · Progress saved in this browser.`:'Choose your current month and days per month to begin.';$('advanceDay').disabled=!c;if(!c&&state.tracking)$('calendarSettings').hidden=false;
const root=$('activeList');root.replaceChildren();if(running.length){const rh=document.createElement('h3');rh.className='action-heading';rh.textContent='Events Still in Progress';root.append(rh)}if(!running.length){const p=document.createElement('p');p.textContent='No ongoing events. Generate an event to add it automatically.';root.append(p)}
running.forEach(item=>{const card=document.createElement('div');card.className='track-card';const top=document.createElement('div');top.className='track-top';const h=document.createElement('h3');h.textContent=item.title;const span=document.createElement('span');span.textContent=item.duration?.unit==='months'?`${item.duration.amount} month${item.duration.amount===1?'':'s'}`:displayDuration(item.duration?.amount||0);top.append(h,span);const desc=document.createElement('p');desc.textContent=displayEventDescription(item);const bar=document.createElement('div');bar.className='progress';const fill=document.createElement('div');fill.className='progress-fill';fill.style.width=item.total?100*(item.total-item.remaining)/item.total+'%':'100%';bar.append(fill);const bottom=document.createElement('div');bottom.className='track-bottom';const rem=document.createElement('small');rem.textContent=displayDuration(item.remaining)+' remaining';bottom.append(rem);if(item.earlyChoice){const btn=document.createElement('button');btn.className='action-done';btn.textContent='✓ I completed the alternative';btn.onclick=()=>completeAction(item.id);card.append(top,desc,bar,bottom,btn)}else card.append(top,desc,bar,bottom);root.append(card)});
const actionRoot=$('requiredActions');actionRoot.replaceChildren();
const actions=state.active.filter(x=>x.actionRequired&&!x.completed);
if(actions.length){
 const header=document.createElement('div');header.className='actions-heading-row';const h=document.createElement('h3');h.textContent=`Pending Offers & Actions (${actions.length})`;h.className='action-heading';header.append(h);actionRoot.append(header);
 const completable=actions.filter(x=>!x.pendingOffer);
 {
  const bulk=document.createElement('button');bulk.type='button';bulk.className='action-done bulk-complete';
  bulk.textContent=completable.length?`✓ Mark All ${completable.length} Actions Completed`:`✓ No Actions to Complete`;
  bulk.disabled=!completable.length;
  bulk.title='Complete pending actions only. Saved dealership offers will not be applied.';
  bulk.onclick=()=>{
   const finished=state.calendar?{...state.calendar}:null;
   state.active.forEach(x=>{if(x.actionRequired&&!x.completed&&!x.pendingOffer){x.completed=true;x.actionRequired=false;x.finished=finished?{...finished}:null;}});
   persist();renderTracker();renderBannerCompletion();syncCleanLayout();
  };
  header.append(bulk);
 }
}
actions.forEach(item=>{const card=document.createElement('div');card.className='track-card required-card';const title=document.createElement('strong');title.textContent=item.title;const desc=document.createElement('p');desc.textContent=displayEventDescription(item);const button=document.createElement('button');button.type='button';button.textContent=item.pendingOffer?'✓ Apply Offer When Used':'✓ Done — I have completed this';button.className='action-done';button.onclick=()=>completeAction(item.id);const copy=document.createElement('div');copy.className='required-copy';copy.append(title,desc);card.append(copy,button);actionRoot.append(card)});
 renderHistory();renderFarmDashboard();renderBannerCompletion();if(typeof syncCleanLayout==='function')syncCleanLayout();}
function renderHistory(){const root=$('historyList');root.replaceChildren();$('historyPanel').hidden=!state.tracking;const completed=state.active.filter(e=>e.completed);if(!completed.length){const p=document.createElement('p');p.className='small-event-note';p.textContent='Completed events will appear here automatically.';root.append(p);return}
const years=[...new Set(completed.map(e=>e.created?.year||0))].sort((a,b)=>b-a);years.forEach(y=>{const yd=document.createElement('details');yd.className='history-year';yd.open=y===years[0];const ys=document.createElement('summary');ys.textContent=`Year ${y+1}`;yd.append(ys);for(let m=0;m<12;m++){const list=completed.filter(e=>(e.created?.year||0)===y&&(e.created?.month||0)===m);if(!list.length)continue;const md=document.createElement('details');md.className='history-month';md.open=y===years[0];const ms=document.createElement('summary');ms.textContent=`${months[m]} (${list.length})`;md.append(ms);list.forEach(e=>{const r=document.createElement('div');r.className='history-row';const name=document.createElement('strong');name.textContent=e.title;const info=document.createElement('small');info.textContent=`${displayEventDescription(e)} · Finished: ${dateLabel(e.finished)}`;r.append(name,info);md.append(r)});yd.append(md)}root.append(yd)})}
function advance(){if(!state.tracking||!state.calendar)return;const c=state.calendar;
// Only immediate mandatory actions block the calendar. Saved offers can be applied at any later date.
const pending=state.active.filter(x=>x.actionRequired&&!x.completed&&!x.pendingOffer);
if(pending.length){
  const msg=`Complete ${pending.length} pending event action${pending.length===1?'':'s'} before advancing the calendar.`;
  $('status').textContent=msg;
  const notice=$('scheduleStatus');if(notice)notice.textContent=msg;
  farmDialog('Please complete all required event actions before continuing to the next day or month. Saved offers can be used later.',{title:'Unfinished Events'});
  return;
}
if(c.day>=c.daysPerMonth){c.day=1;c.month=(c.month+1)%12;if(c.month===0)c.year=(c.year||0)+1}else c.day++;
if(c.day===1||state.frequency==='daily'){state.periodEvents=[];state.periodKey=null;state.current=null;}state.active.forEach(x=>{if(!x.completed&&x.remaining>0){x.remaining=Math.max(0,x.remaining-1);if(x.remaining===0){x.completed=true;x.finished={...c}}}});persist();renderTracker();renderSchedule();syncCleanLayout();renderBannerCompletion();
// Automatically draw the new day's/month's scheduled events after advancing.
// Manual mode stays manual; do not generate twice for an already drawn period.
if(state.frequency!=='manual'&&dueForPeriod()&&!monthAlreadyGenerated())generate();
}
$('advanceDay').onclick=advance;
$('activeToggle').onclick=()=>{toggleOngoing()};
function updateTracking(){state.tracking=$('enableTracking').checked;$('activeToggle').hidden=true;$('calendarSettings').hidden=!state.tracking;if(state.tracking&&!state.calendar)openSettings();persist();renderTracker();renderSchedule();syncCleanLayout()}
$('enableTracking').onchange=updateTracking;
function periodId(){const c=state.calendar;if(!c||state.frequency==='manual')return null;if(state.frequency==='daily')return `${c.year||0}-${c.month}-${c.day}`;const every=Number(state.frequency);const abs=(c.year||0)*12+c.month;return Math.floor((abs-(state.scheduleAnchor??abs))/every)}
function dueForPeriod(){if(!state.calendar||state.frequency==='manual')return false;if(state.frequency==='daily')return true;const c=state.calendar;const every=Number(state.frequency);const abs=(c.year||0)*12+c.month;return (abs-(state.scheduleAnchor??abs))%every===0}
function renderSchedule(){const manual=state.frequency==='manual';$('countField').hidden=false;$('scheduleBox').hidden=true;$('frequency').value=state.frequency;$('minEvents').value=String(state.minEvents);$('maxEvents').value=String(state.maxEvents);if(manual)return;const c=state.calendar;const status=$('scheduleStatus');const btn=$('revealDue');if(!state.tracking||!c){status.textContent='Enable Farm Calendar & Event Tracking and set your in-game date to schedule events.';btn.disabled=true;return}const period=periodId();btn.textContent=state.frequency==='daily'?`${months[c.month]} Farm Update — Day ${c.day}`:`${months[c.month]} Farm Update`;if(!dueForPeriod()){const abs=(c.year||0)*12+c.month;const anchor=state.scheduleAnchor??abs;const next=abs+(Number(state.frequency)-((abs-anchor)%Number(state.frequency)));status.textContent=`Next scheduled events will be due in ${months[next%12]}, Year ${Math.floor(next/12)+1}.`;btn.disabled=true;return}if(state.periodKey!==`${state.frequency}:${period}`){state.periodKey=`${state.frequency}:${period}`;persist()}btn.disabled=state.periodEvents.length>0;status.textContent=state.periodEvents.length?`${state.periodEvents.length} different events generated for ${months[c.month]}${state.frequency==='daily'?' Day '+c.day:''}. Select their photographs above to view each event.`:`Events are due for ${months[c.month]}${state.frequency==='daily'?' Day '+c.day:''}. Generate them when you're ready.`;}
$('frequency').onchange=()=>{state.frequency=$('frequency').value;if(state.calendar)state.scheduleAnchor=(state.calendar.year||0)*12+state.calendar.month;state.periodKey=null;state.periodEvents=[];state.current=null;persist();renderThumbnails();renderSchedule();syncCleanLayout()};
function updateEventRange(changed){let min=Number($('minEvents').value),max=Number($('maxEvents').value);if(min>max){if(changed==='min')max=min;else min=max;}state.minEvents=min;state.maxEvents=max;state.count=min===max?String(min):'random';persist();renderSchedule();syncCleanLayout();}
$('minEvents').onchange=()=>updateEventRange('min');
$('maxEvents').onchange=()=>updateEventRange('max');
$('revealDue').onclick=generate;

function monthAlreadyGenerated(){return !!(state.calendar&&state.monthGenerated[monthKey()]);}
function updateGoldLabel(){
 const b=$('generate'), sticky=$('sticky');
 if(!state.calendar||!state.tracking){b.disabled=false;sticky.disabled=false;b.textContent='⟳ FARM UPDATE';sticky.textContent='⟳ Farm Update';return;}
 const c=state.calendar, month=months[c.month];
 let label;
 if(!monthAlreadyGenerated()&&(state.frequency==='manual'||dueForPeriod()))label=state.frequency==='daily'?`${month} Farm Update — Day ${c.day}`:`${month} Farm Update`;
 else if(c.day<c.daysPerMonth)label=`Advance to Day ${c.day+1}`;
 // Completed actions are required; timed events may continue.

 else label=`Advance to ${months[(c.month+1)%12]}`;
 b.textContent='⟳  '+label.toUpperCase();sticky.textContent='⟳ '+label;
 b.disabled=false;sticky.disabled=false;
}
function mainGoldAction(){
 if(!state.tracking||!state.calendar){generate();return;}
 if(!monthAlreadyGenerated()&&(state.frequency==='manual'||dueForPeriod())){generate();return;}
 advance();
}
let setupOpen=false,ongoingOpen=!!state.ongoingOpen;
function syncCleanLayout(){
 const hasFarm=!!state.calendar&&state.tracking;
 $('calendarSettings').hidden=!state.tracking||!setupOpen;
 $('farmSetup').hidden=!setupOpen;
 $('farmStatus').hidden=!hasFarm;
 $('activeToggle').hidden=true;
 $('tracker').hidden=!hasFarm||!ongoingOpen;
 $('ongoingMount').hidden=!ongoingOpen;
 $('ongoingTop').setAttribute('aria-expanded',String(ongoingOpen));
 $('ongoingShow').textContent=ongoingOpen?'Hide ▴':'Show ▾';
 const running=state.active.filter(e=>!e.completed&&!e.actionRequired).length;const required=state.active.filter(e=>!e.completed&&e.actionRequired).length;
 $('ongoingCount').textContent=`${running} Ongoing · ${required} Action${required===1?'':'s'} Required`;
 if(hasFarm){const c=state.calendar;const nextMonth=months[(c.month+1)%12];$('farmDateTop').textContent=`${months[c.month]} — Year ${(c.year||0)+1} · Day ${c.day} of ${c.daysPerMonth}`;$('advanceTop').textContent=c.day>=c.daysPerMonth?`Advance to ${nextMonth}`:`Advance to Day ${c.day+1}`;}
 $('historyDetails').hidden=!hasFarm;
 $('compactFarmDate').parentElement.hidden=true;
 $('compactFarmDate').textContent=hasFarm?`${months[state.calendar.month]} — Year ${(state.calendar.year||0)+1} · Day ${state.calendar.day} of ${state.calendar.daysPerMonth}`:'YOUR FARM · Set up your calendar';
 updateGoldLabel();
}
function toggleOngoing(){ongoingOpen=!ongoingOpen;state.ongoingOpen=ongoingOpen;persist();syncCleanLayout()}
$('ongoingTop').onclick=toggleOngoing;

function showSetup(){setupOpen=true;$('farmSetup').hidden=false;$('closeSetup').hidden=!state.calendar;openSettings();$('calendarSettings').hidden=!$('enableTracking').checked;syncCleanLayout();$('farmSetup').scrollIntoView({behavior:'smooth',block:'start'})}
$('farmSettingsMenu').onclick=e=>{e.preventDefault();showSetup()};
$('finishSetup').onclick=()=>{state.tracking=$('enableTracking').checked;if(state.tracking){$('calendarSave').click();}else{state.periodEvents=[];state.current=null;state.used=[];persist();renderTracker();renderSchedule();}setupOpen=false;syncCleanLayout();$('event').scrollIntoView({behavior:'smooth',block:'center'})};
$('closeSetup').onclick=()=>{setupOpen=false;syncCleanLayout()};

// A new save should clear progress without changing player preferences.
const newFarmButton=document.createElement('button');
newFarmButton.type='button';
newFarmButton.id='newFarmReset';
newFarmButton.className='select-all';
newFarmButton.textContent='↻ Start New Farm / Reset Progress';
newFarmButton.style.cssText='display:block;margin:18px 0 6px;padding:11px 16px;';
newFarmButton.title='Clears farm events and calendar, but keeps your selected categories and preferences';
$('farmSetup').append(newFarmButton);
const resetExplanation=document.createElement('p');
resetExplanation.className='calendar-note';
resetExplanation.textContent='Clears this farm’s events, history and calendar. Keeps your category, animal, crop and event preferences.';
$('farmSetup').append(resetExplanation);
newFarmButton.addEventListener('click',()=>{
 farmDialog('Start a new farm? This will permanently clear all active events, completed history and the farm calendar saved in this browser. Your event preferences will be kept.',{title:'Start New Farm',confirm:true,confirmLabel:'Yes, Start New Farm',onConfirm:()=>{
 const fresh={
   selected:[...state.selected],current:null,used:[],active:[],categoriesOpen:state.categoriesOpen,
   tracking:state.tracking,calendar:null,frequency:state.frequency,count:state.count,minEvents:state.minEvents,maxEvents:state.maxEvents,currency:state.currency,areaUnit:state.areaUnit,
   periodKey:null,periodEvents:[],scheduleAnchor:null,monthSeen:{},monthGenerated:{},
   lastGenerated:null,sequence:0,animalsOwned:[...state.animalsOwned],cropsOwned:[...state.cropsOwned],ongoingOpen:false
 };
 try{localStorage.setItem(KEY,JSON.stringify(fresh))}catch(e){}
 window.location.reload();
}});
});

// Farm Settings: persist individual selections, with independent select-all controls.
function makeFarmSelectionSection(title,description,names,stateKey,optionsId){
 const section=document.createElement('section');
 section.className='crop-settings';
 section.innerHTML=`<h3>${title}</h3><p>${description}</p><div class="crop-options" id="${optionsId}"></div>`;
 const options=section.querySelector('#'+optionsId);
 const allLabel=document.createElement('label');
 allLabel.className='farm-select-all';
 const allCheck=document.createElement('input');
 allCheck.type='checkbox';
 const allText=document.createTextNode(' Select All / Deselect All');
 allLabel.append(allCheck,allText);
 options.append(allLabel);
 const checks=[];
 function syncAll(){
   const selected=checks.filter(c=>c.checked).length;
   allCheck.checked=selected===names.length;
   allCheck.indeterminate=selected>0&&selected<names.length;
 }
 allCheck.addEventListener('change',()=>{
   state[stateKey]=allCheck.checked?[...names]:[];
   checks.forEach(check=>{check.checked=allCheck.checked});
   syncAll();persist();renderSchedule();
 });
 names.forEach(name=>{
   const label=document.createElement('label');const check=document.createElement('input');
   check.type='checkbox';check.checked=state[stateKey].includes(name);
   check.addEventListener('change',()=>{
     state[stateKey]=check.checked?[...new Set([...state[stateKey],name])]:state[stateKey].filter(x=>x!==name);
     syncAll();persist();renderSchedule();
   });
   label.append(check,document.createTextNode(' '+name));options.append(label);checks.push(check);
 });
 syncAll();
 return {section,checks,syncAll};
}
const areaSection=document.createElement('section');
areaSection.className='crop-settings area-unit-settings';
areaSection.innerHTML='<h3>Field Measurements</h3><p>Choose which field-size measurement appears in your random events.</p><div class="area-unit-options" role="group" aria-label="Field measurements"><button type="button" data-unit="acres">Acres</button><button type="button" data-unit="hectares">Hectares</button></div>';
const areaButtons=[...areaSection.querySelectorAll('button')];
function syncAreaButtons(){areaButtons.forEach(b=>{const selected=b.dataset.unit===state.areaUnit;b.setAttribute('aria-pressed',String(selected));b.classList.toggle('selected',selected)})}
areaButtons.forEach(b=>b.addEventListener('click',()=>{state.areaUnit=b.dataset.unit;syncAreaButtons();persist();if(state.current)showEvent(state.current);renderTracker();renderSchedule()}));
syncAreaButtons();
// Keep the existing field measurement buttons and their appearance unchanged.
const currencySection=document.createElement('section');
currencySection.className='crop-settings area-unit-settings';
currencySection.innerHTML='<h3>Currency</h3><p>Choose the currency shown in random events.</p><div class="area-unit-options" role="group" aria-label="Currency"><button type="button" data-currency="GBP">£ Pound</button><button type="button" data-currency="EUR">€ Euro</button><button type="button" data-currency="USD">$ Dollar</button></div>';
const currencyButtons=[...currencySection.querySelectorAll('button')];
function syncCurrencyButtons(){currencyButtons.forEach(b=>{const selected=b.dataset.currency===state.currency;b.setAttribute('aria-pressed',String(selected));b.classList.toggle('selected',selected)})}
function refreshCurrency(){syncCurrencyButtons();document.querySelector('label[for="calcPrice"]').textContent='Normal price ('+currencySymbol()+')';document.querySelectorAll('#calcPriceOptions button').forEach(b=>{b.textContent=money(Number(b.dataset.price))});updateCalculator();if(state.current)showEvent(state.current);renderTracker();renderHistory()}
currencyButtons.forEach(b=>b.addEventListener('click',()=>{state.currency=b.dataset.currency;persist();refreshCurrency()}));
const unitCurrencyRow=document.createElement('div');unitCurrencyRow.className='fsg-unit-currency-row';unitCurrencyRow.append(areaSection,currencySection);
$('setupMount').prepend(unitCurrencyRow);
const unitCurrencyStyle=document.createElement('style');unitCurrencyStyle.textContent='.fsg-unit-currency-row{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.fsg-unit-currency-row>.crop-settings{margin:0;min-width:0}.fsg-unit-currency-row .area-unit-options{display:flex;flex-wrap:wrap;gap:7px}@media(max-width:540px){.fsg-unit-currency-row{gap:8px}.fsg-unit-currency-row>.crop-settings{padding:12px 8px}.fsg-unit-currency-row .area-unit-options button{font-size:.8rem;padding:7px 9px}}';document.head.append(unitCurrencyStyle);
syncCurrencyButtons();
const animalSettings=makeFarmSelectionSection('Your Animals','Select the animals you keep. Animal-specific events require the relevant animal to be selected.',animalNames,'animalsOwned','animalOptions');
const cropSettings=makeFarmSelectionSection('Your Crops','Select the crops you grow. Events about any crop or field remain available whenever you grow at least one crop.',cropNames,'cropsOwned','cropOptions');
$('setupMount').prepend(animalSettings.section);
$('setupMount').prepend(cropSettings.section);
const resetFarmSettings=document.createElement('button');
resetFarmSettings.type='button';resetFarmSettings.className='bulk-complete';
resetFarmSettings.textContent='Reset Farm Settings';
resetFarmSettings.style.cssText='margin:12px 0 16px;padding:9px 14px;';
resetFarmSettings.title='Deselect every animal and crop; keep your existing farm events and calendar';
resetFarmSettings.addEventListener('click',()=>{
 farmDialog('Deselect all crops and animals? Your event history and calendar will be kept.',{title:'Reset Farm Settings',confirm:true,confirmLabel:'Yes, Reset',onConfirm:()=>{
 state.animalsOwned=[];state.cropsOwned=[];
 [...animalSettings.checks,...cropSettings.checks].forEach(check=>{check.checked=false});
 animalSettings.syncAll();cropSettings.syncAll();persist();renderSchedule();
}});
});
cropSettings.section.after(resetFarmSettings);
// The calendar, tracking toggle, and frequency controls live in one setup panel.
$('setupMount').append($('tracking-optin-placeholder')||$('enableTracking').closest('.tracking-optin'),$('calendarSettings'),$('frequencyPanel'));
$('calendarEdit').onclick=showSetup;

// Compact three-column Farm Event Dashboard. This is a view of existing state only.
let dashboardOpen='';
const dashboardStyle=document.createElement('style');
dashboardStyle.textContent=`
#farmEventDashboard{margin:0 0 14px;color:#fff}
.fsg-dash-heading{font-size:1.18rem;color:#f0c568;margin:0 0 12px;font-weight:700}
.fsg-dash-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:9px}
.fsg-dash-tab{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:5px;min-height:90px;padding:10px 5px;background:#0b3326;border:1px solid #b99043;border-radius:10px;color:white;cursor:pointer;font:inherit;text-align:center}
.fsg-dash-tab[aria-expanded="true"]{background:#12402f;border-color:#f1c469}
.fsg-dash-number{font-size:1.7rem;font-weight:800;color:#f1c469;line-height:1}
.fsg-dash-label{font-size:.83rem;font-weight:650}
.fsg-dash-arrow{color:#f1c469;font-size:.85rem}
.fsg-dash-content{margin-top:12px;display:grid;gap:9px}
.fsg-dash-row{background:#0b3326;border:1px solid #b99043;border-radius:8px;padding:12px;display:grid;gap:7px}
.fsg-dash-row strong{color:#fff}
.fsg-dash-row p{margin:0;color:#d5e4da;font-size:.9rem;line-height:1.45}
.fsg-dash-row small{color:#f1c469}
.fsg-dash-done{justify-self:end;border:1px solid #d9ad54;background:#0b3326;color:#f1c469;border-radius:7px;padding:8px 12px;font-weight:700;cursor:pointer}.fsg-dash-done:hover:not(:disabled){background:#194b37;border-color:#f1c469}
.fsg-dash-done.is-completed{background:#d8ad51;border-color:#e2b85d;color:#173b29;cursor:default}
.fsg-dash-progress{height:9px;border-radius:20px;overflow:hidden;background:#092f22;border:1px solid #426b52}
.fsg-dash-progress-fill{height:100%;background:linear-gradient(90deg,#c99a38,#f1c469);transition:width .2s}
.fsg-dash-row.is-completed{border-color:#a88b4b}
.fsg-dash-tile{display:flex;flex-direction:column;align-items:stretch;min-width:0;background:#0b3326;border:1px solid #b99043;border-radius:10px;overflow:hidden}
.fsg-dash-tile .fsg-dash-tab{border:0;border-radius:0;min-height:72px}
.fsg-dash-tile:has(.fsg-dash-tab[aria-expanded="true"]){border-color:#f1c469}
.fsg-dash-tile .fsg-dash-bulk{align-self:stretch;justify-self:stretch;margin:0 7px 8px;padding:7px 3px;font-size:.74rem;line-height:1.2}
.fsg-dash-bulk:disabled{opacity:.65;cursor:default}
.fsg-dash-empty{color:#d5e4da;margin:8px 0}.fsg-dash-bulk{justify-self:end;margin-top:5px;border:1px solid #d9ad54;background:#0b3326;color:#f1c469;border-radius:7px;padding:10px 14px;font:inherit;font-weight:700;cursor:pointer}.fsg-dash-bulk:hover{background:#194b37}
@media(max-width:420px){.fsg-dash-grid{gap:5px}.fsg-dash-tab{min-height:82px;padding:8px 3px}.fsg-dash-label{font-size:.72rem}.fsg-dash-number{font-size:1.5rem}}
`;
document.head.append(dashboardStyle);
const dashboard=document.createElement('div');dashboard.id='farmEventDashboard';
$('tracker').prepend(dashboard);
$('requiredActions').style.display='none';
$('activeList').style.display='none';
function renderFarmDashboard(){
 const isFinishedToday=x=>x.completed && (!state.calendar || (x.finished && x.finished.year===state.calendar.year && x.finished.month===state.calendar.month && x.finished.day===state.calendar.day));
 const actions=state.active.filter(x=>!x.pendingOffer && (x.actionRequired&&!x.completed || (isFinishedToday(x)&&!x.total)));
 const offers=state.active.filter(x=>x.pendingOffer && (!x.completed || isFinishedToday(x)));
 const running=state.active.filter(x=>!x.completed&&!x.actionRequired);
 const counts={actions:actions.length,ongoing:running.length,offers:offers.length};
 dashboard.replaceChildren();
 const heading=document.createElement('h2');heading.className='fsg-dash-heading';heading.textContent='Farm Event Dashboard';dashboard.append(heading);
 const grid=document.createElement('div');grid.className='fsg-dash-grid';
 [['actions','Actions'],['ongoing','In Progress'],['offers','Saved Offers']].forEach(([key,label])=>{
  const tile=document.createElement('div');tile.className='fsg-dash-tile';
  const b=document.createElement('button');b.type='button';b.className='fsg-dash-tab';
  b.setAttribute('aria-expanded',String(dashboardOpen===key));
  b.innerHTML=`<span class="fsg-dash-number">${counts[key]}</span><span class="fsg-dash-label">${label}</span><span class="fsg-dash-arrow">${dashboardOpen===key?'▴':'▾'}</span>`;
  b.onclick=()=>{dashboardOpen=dashboardOpen===key?'':key;renderFarmDashboard()};tile.append(b);
  if(key==='actions'){
   const outstanding=actions.filter(x=>!x.completed);
   const bulk=document.createElement('button');bulk.type='button';bulk.className='fsg-dash-bulk';
   bulk.textContent=outstanding.length?'✓ Complete All':'✓ All Done';bulk.disabled=!outstanding.length;
   bulk.title='Complete all outstanding actions; saved offers are excluded.';
   bulk.onclick=()=>{
    const now=state.calendar?{...state.calendar}:null;
    outstanding.forEach(x=>{x.completed=true;x.actionRequired=false;x.finished=now?{...now}:null;});
    persist();renderTracker();renderBannerCompletion();syncCleanLayout();
   };
   tile.append(bulk);
  }
  grid.append(tile);
 });dashboard.append(grid);
 if(!dashboardOpen)return;
 const content=document.createElement('div');content.className='fsg-dash-content';dashboard.append(content);
 const items=dashboardOpen==='actions'?actions:dashboardOpen==='offers'?offers:running;
 if(!items.length){const p=document.createElement('p');p.className='fsg-dash-empty';p.textContent=dashboardOpen==='actions'?'No actions required.':dashboardOpen==='offers'?'No saved offers.':'No events in progress.';content.append(p);return;}
 items.forEach(item=>{
  const card=document.createElement('div');card.className='fsg-dash-row';if(item.completed)card.classList.add('is-completed');
  const title=document.createElement('strong');title.textContent=item.title;card.append(title);
  const desc=document.createElement('p');desc.textContent=displayEventDescription(item);card.append(desc);
  if(dashboardOpen==='ongoing'){
   const progress=document.createElement('div');progress.className='fsg-dash-progress';progress.setAttribute('role','progressbar');
   const percent=item.total?Math.max(0,Math.min(100,100*(item.total-item.remaining)/item.total)):0;progress.setAttribute('aria-valuenow',String(Math.round(percent)));progress.setAttribute('aria-valuemin','0');progress.setAttribute('aria-valuemax','100');
   const fill=document.createElement('div');fill.className='fsg-dash-progress-fill';fill.style.width=percent+'%';progress.append(fill);card.append(progress);
   const rem=document.createElement('small');rem.textContent=item.duration?.unit==='months'?`${Math.ceil(item.remaining/(state.calendar?.daysPerMonth||3))} month(s) remaining`:displayDuration(item.remaining)+' remaining';card.append(rem);
  }
  if(dashboardOpen!=='ongoing'){
   const btn=document.createElement('button');btn.type='button';btn.className='fsg-dash-done';
   btn.textContent=item.completed?'✓ Completed':item.pendingOffer?'✓ Apply Offer When Used':'✓ Mark as Completed';
   if(item.completed){btn.classList.add('is-completed');btn.disabled=true;}else btn.onclick=()=>completeAction(item.id);card.append(btn);
  }
  content.append(card);
 });

}

$('tracker').querySelector('.calendar-box').hidden=true;
// The farm date is already displayed above the advance button; avoid duplicating it inside the tracker.
const duplicateFarmDate=$('compactFarmDate');if(duplicateFarmDate?.parentElement)duplicateFarmDate.parentElement.hidden=true;
$('ongoingMount').append($('tracker'));
$('historyPanel').hidden=false;
const hist=$('historyPanel');const summary=document.createElement('summary');summary.textContent='Farm Event History — Show / Hide';const detail=document.createElement('details');detail.className=hist.className;detail.id='historyDetails';hist.parentNode.insertBefore(detail,hist);detail.append(summary,hist);hist.className='history-content';hist.style.cssText='margin-top:8px;border:0;padding:0;background:transparent';
if(!state.calendar){setupOpen=true;$('calendarSettings').hidden=!state.tracking}
$('enableTracking').checked=true;
// Show the original optional-calendar control. The demo requires the calendar to
// enforce one event per in-game month, so explain this if someone switches it off.
const demoCalendarToggle=$('enableTracking').closest('.tracking-optin');
demoCalendarToggle.hidden=false;demoCalendarToggle.style.display='';
const calendarHelp=demoCalendarToggle.querySelector('p');
if(calendarHelp)calendarHelp.textContent='The free demo uses the farm calendar to limit events to one per month. You can change the month and days per month in Farm Settings.';
$('enableTracking').addEventListener('change',()=>{if(!$('enableTracking').checked){$('enableTracking').checked=true;farmDialog('The free demo uses the farm calendar to provide one event per month. Calendar tracking can be optional in the full version.',{title:'Demo Calendar'});}});
drawCats();if(!state.current)state.current=instantiate(events[0]);showEvent(state.current);updateTracking();renderSchedule();syncCleanLayout();refreshCurrency();
if(typeof IntersectionObserver!=='undefined'){const obs=new IntersectionObserver(es=>{$('sticky').classList.toggle('show',!es[0].isIntersecting)},{threshold:.2});obs.observe($('generate'))}

/* Free demo: photographic category padlocks, without changing the full generator. */
const demoLockStyle=document.createElement('style');demoLockStyle.textContent=`.category.demo-locked{position:relative;overflow:hidden;opacity:1!important;cursor:not-allowed;filter:none!important}.category.demo-locked img{filter:brightness(.48) saturate(.65)}.category.demo-locked .demo-lock-overlay{position:absolute;inset:0;background:rgba(3,25,17,.42);display:flex;flex-direction:column;justify-content:center;align-items:center;gap:8px;padding:5px 3px 27px;pointer-events:none;z-index:3}.category.demo-locked .demo-lock-symbol{display:flex;align-items:center;justify-content:center;width:clamp(38px,5vw,64px);height:clamp(38px,5vw,64px);filter:drop-shadow(0 2px 4px #071b11)}.category.demo-locked .demo-lock-symbol svg{width:100%;height:100%;display:block}.category.demo-locked .demo-lock-label{font-size:clamp(8px,1vw,11px);line-height:1.2;white-space:nowrap;letter-spacing:.025em;font-weight:800;color:#f5d489;background:rgba(4,31,21,.88);padding:4px 6px;border-radius:4px}.category.demo-locked .name{position:relative;z-index:4}.category.demo-locked .tick{display:none}#all:disabled{opacity:.8;cursor:default}@media(max-width:650px){.category.demo-locked .demo-lock-overlay{gap:3px;padding:2px 1px 29px}.category.demo-locked .demo-lock-symbol{width:clamp(25px,7vw,35px);height:clamp(25px,7vw,35px)}.category.demo-locked .demo-lock-label{font-size:clamp(6px,1.5vw,8px);letter-spacing:0;padding:2px 2px}}`;document.head.append(demoLockStyle);
